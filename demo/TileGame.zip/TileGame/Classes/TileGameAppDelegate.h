//
//  TileGameAppDelegate.h
//  TileGame
//
//  Created by Ray Wenderlich on 5/18/10.
//  Copyright Ray Wenderlich 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TileGameAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
